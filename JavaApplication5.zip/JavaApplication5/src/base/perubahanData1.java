/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package base;
import java.awt.Cursor;
import java.io.File;
import java.io.IOException;
import java.awt.Font;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author teknisi
 */
public class perubahanData1 extends javax.swing.JFrame {

    /**
     * Creates new form perubahanData1
     */
    public perubahanData1() {
        setUndecorated(true);
        initComponents();
        loadData();
        
    }
    
 private void exportToPDF(File file) {
    try (PDDocument document = new PDDocument()) {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);

        PDPageContentStream contentStream = new PDPageContentStream(document, page);

        // Load custom font
        PDType0Font font = PDType0Font.load(document, new File("src/font/Segoe_UI_Bold.ttf")); // Pastikan font bold tersedia

        // Judul
        String title = "Data Barang";
        contentStream.setFont(font, 16);
        float titleWidth = font.getStringWidth(title) / 1000 * 16; // Menghitung lebar teks judul
        float titleX = (page.getMediaBox().getWidth() - titleWidth) / 2; // Menghitung posisi X agar teks berada di tengah

        contentStream.beginText();
        contentStream.newLineAtOffset(titleX, 750); // Posisi Y tetap sama, posisi X sesuai perhitungan
        contentStream.showText(title);
        contentStream.endText();

        // Header Tabel
        contentStream.setFont(font, 12);
        float startX = 50;
        float startY = 700;
        float rowHeight = 20;
        
        String[] headers = {"Nama Barang", "Deskripsi", "Stock", "SKU"};
        float[] columnWidths = {150, 150, 50, 150};

        // Menampilkan header
        for (int i = 0; i < headers.length; i++) {
            contentStream.beginText();
            contentStream.newLineAtOffset(startX, startY); // Offset vertikal untuk header
            contentStream.showText(headers[i]);
            contentStream.endText();
            startX += columnWidths[i]; // Geser startX ke awal kolom berikutnya
        }

        // Garis di bawah header
        contentStream.moveTo(50, startY - 5);
        contentStream.lineTo(550, startY - 5);
        contentStream.stroke();

        // Data Tabel
        contentStream.setFont(PDType0Font.load(document, new File("src/font/Segoe_UI.ttf")), 10); // Gunakan font regular untuk data
        startY -= rowHeight; // Geser ke baris berikutnya

        // Menampilkan data
        for (int row = 0; row < nama_tabel.getRowCount(); row++) {
            startX = 50; // Reset startX untuk setiap baris
            for (int col = 0; col < nama_tabel.getColumnCount(); col++) {
                Object value = nama_tabel.getValueAt(row, col);
                contentStream.beginText();
                contentStream.newLineAtOffset(startX, startY - row * rowHeight); // Offset vertikal untuk data
                contentStream.showText(value.toString());
                contentStream.endText();
                startX += columnWidths[col]; // Geser startX ke awal kolom berikutnya
            }
            startY -= rowHeight; // Geser ke baris berikutnya
        }

        contentStream.close();

        document.save(file);
        document.close();

        JOptionPane.showMessageDialog(null, "Data berhasil di-export sebagai PDF: " + file.getAbsolutePath());

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error saat menyimpan file PDF: " + e.getMessage());
    }
}


    
    private void TabelDataMouseClicked(java.awt.event.MouseEvent evt) {                                         
    int selectedRow = nama_tabel.getSelectedRow();
    DefaultTableModel model = (DefaultTableModel) nama_tabel.getModel();
    
    t_namabarang.setText(model.getValueAt(selectedRow, 0).toString());
    t_desk.setText(model.getValueAt(selectedRow, 1).toString());
    t_stock.setText(model.getValueAt(selectedRow, 2).toString());
    t_sku.setText(model.getValueAt(selectedRow, 3).toString());
}
    
    private void loadData() {
        DefaultTableModel model = (DefaultTableModel) nama_tabel.getModel();
        model.setRowCount(0);

        try (Connection conn = db_dataConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM nama_tabel");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("nama_barang"),
                    rs.getString("deskripsi"),
                    rs.getInt("stock"),
                    rs.getString("sku")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        nama_tabel = new javax.swing.JTable();
        btn_export = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        t_sku = new javax.swing.JTextField();
        t_namabarang = new javax.swing.JTextField();
        t_desk = new javax.swing.JTextField();
        t_stock = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btn_save = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        btn_reset = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btn_update = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        btn_delete = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        btn_out = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nama_tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "nama", "deskripsi", "stock", "sku"
            }
        ));
        nama_tabel.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                nama_tabelAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        nama_tabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_tabelMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(nama_tabel);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 430, 210));

        btn_export.setText("Export PDF");
        btn_export.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exportActionPerformed(evt);
            }
        });
        getContentPane().add(btn_export, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 540, 90, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("SKU");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Nama Barang");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Deskripsi");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Stock");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));
        getContentPane().add(t_sku, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 310, -1));

        t_namabarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_namabarangActionPerformed(evt);
            }
        });
        getContentPane().add(t_namabarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 310, -1));
        getContentPane().add(t_desk, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 310, -1));
        getContentPane().add(t_stock, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, 310, -1));
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, -1, -1));
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, -1, -1));
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 150, -1, -1));
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 150, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/diskette (1).png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, -1, -1));

        btn_save.setText("Save");
        btn_save.setHideActionText(true);
        btn_save.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btn_save.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_saveMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_saveMouseExited(evt);
            }
        });
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        getContentPane().add(btn_save, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 70, 70));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/refresh-arrow (1).png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, -1, -1));

        btn_reset.setText("Reset");
        btn_reset.setHideActionText(true);
        btn_reset.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btn_reset.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_reset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_resetMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_resetMouseExited(evt);
            }
        });
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });
        getContentPane().add(btn_reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 70, 70));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/sync (1).png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 240, -1, -1));

        btn_update.setText("Update");
        btn_update.setHideActionText(true);
        btn_update.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btn_update.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_updateMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_updateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_updateMouseExited(evt);
            }
        });
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        getContentPane().add(btn_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, -1, 70));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/delete (1).png"))); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 240, -1, -1));

        btn_delete.setText("Delete");
        btn_delete.setHideActionText(true);
        btn_delete.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btn_delete.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_deleteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_deleteMouseExited(evt);
            }
        });
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        getContentPane().add(btn_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 230, 70, 70));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/logout (1).png"))); // NOI18N
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, -1, -1));

        btn_out.setText("Out");
        btn_out.setHideActionText(true);
        btn_out.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btn_out.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_out.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_outMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_outMouseExited(evt);
            }
        });
        btn_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_outActionPerformed(evt);
            }
        });
        getContentPane().add(btn_out, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 230, 70, 70));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ui_asset/perubahan_data-04.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void nama_tabelAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_nama_tabelAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_nama_tabelAncestorAdded

    private void btn_exportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exportActionPerformed
        JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Simpan sebagai PDF");

    int userSelection = fileChooser.showSaveDialog(this);

    if (userSelection == JFileChooser.APPROVE_OPTION) {
        File fileToSave = fileChooser.getSelectedFile();

        // Pastikan nama file diakhiri dengan .pdf
        if (!fileToSave.getName().endsWith(".pdf")) {
            fileToSave = new File(fileToSave.getAbsolutePath() + ".pdf");
        }

        exportToPDF(fileToSave);
    }
    }//GEN-LAST:event_btn_exportActionPerformed
    
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
    // Ambil data dari field input
        String namaBarang = t_namabarang.getText();
        String deskripsi = t_desk.getText();
        String stock = t_stock.getText();
        String sku = t_sku.getText();

        // Simpan data ke database
        try (Connection conn = db_dataConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO nama_tabel (nama_barang, deskripsi, stock, sku) VALUES (?, ?, ?, ?)")) {

            stmt.setString(1, namaBarang);
            stmt.setString(2, deskripsi);
            stmt.setInt(3, Integer.parseInt(stock));
            stmt.setString(4, sku);
            stmt.executeUpdate();

            // Tambahkan data ke model tabel
            DefaultTableModel model = (DefaultTableModel) nama_tabel.getModel();
            model.addRow(new Object[]{namaBarang, deskripsi, stock, sku});

            // Tampilkan pesan berhasil
            JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error saving data: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_outActionPerformed
//        // TODO add your handling code here:
//        int result = JOptionPane.showConfirmDialog(this, "Apakah Anda ingin keluar dari pro?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
//        if (result == JOptionPane.YES_OPTION) {
//            dispose();
//        } else if (result == JOptionPane.NO_OPTION) {
//            //None
//        }
//        this.setVisible(false); // 'this' merujuk pada instance dari Calculator.java

        // Membuat instance dari NewJFrame dan mengatur visibilitasnya menjadi true
        NewJFrame newFrame = new NewJFrame();
        newFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_btn_outActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        t_namabarang.setText("");
        t_desk.setText("");
        t_stock.setText("");
        t_sku.setText("");
    }//GEN-LAST:event_btn_resetActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
    int selectedRow = nama_tabel.getSelectedRow();

        if (selectedRow != -1) {
            DefaultTableModel model = (DefaultTableModel) nama_tabel.getModel();
            String sku = (String) model.getValueAt(selectedRow, 3);

            // Hapus data dari database
            try (Connection conn = db_dataConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM nama_tabel WHERE sku = ?")) {

                stmt.setString(1, sku);
                stmt.executeUpdate();

                // Menghapus baris dari model tabel
                model.removeRow(selectedRow);
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting data: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Pilih baris yang akan dihapus", "Tidak ada baris dipilih", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void t_namabarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_namabarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_namabarangActionPerformed
    
    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
    JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!");
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_updateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_updateMouseClicked

    private void nama_tabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_tabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_nama_tabelMouseClicked

    private void btn_saveMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_saveMouseEntered
        btn_save.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btn_saveMouseEntered

    private void btn_saveMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_saveMouseExited
        btn_save.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btn_saveMouseExited

    private void btn_resetMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_resetMouseEntered
        // TODO add your handling code here:
        btn_reset.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btn_resetMouseEntered

    private void btn_resetMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_resetMouseExited
        btn_reset.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btn_resetMouseExited

    private void btn_updateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_updateMouseEntered
        btn_update.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btn_updateMouseEntered

    private void btn_updateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_updateMouseExited
        btn_update.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btn_updateMouseExited

    private void btn_deleteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_deleteMouseEntered
        btn_delete.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btn_deleteMouseEntered

    private void btn_deleteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_deleteMouseExited
        btn_delete.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btn_deleteMouseExited

    private void btn_outMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_outMouseEntered
        // TODO add your handling code here:
        btn_out.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btn_outMouseEntered

    private void btn_outMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_outMouseExited
        // TODO add your handling code here:
        btn_out.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btn_outMouseExited
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(perubahanData1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(perubahanData1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(perubahanData1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(perubahanData1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new perubahanData1().setVisible(true);
        });
    }
        

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_export;
    private javax.swing.JButton btn_out;
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable nama_tabel;
    private javax.swing.JTextField t_desk;
    private javax.swing.JTextField t_namabarang;
    private javax.swing.JTextField t_sku;
    private javax.swing.JTextField t_stock;
    // End of variables declaration//GEN-END:variables
}
