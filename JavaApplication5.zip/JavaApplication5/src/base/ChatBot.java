package base;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChatBot extends JFrame implements ActionListener {
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;

    public ChatBot() {
        // Pengaturan frame
        setTitle("ChatBot");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Area untuk menampilkan percakapan
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(chatArea);

        // Field untuk memasukkan teks
        inputField = new JTextField();
        inputField.setFont(new Font("Arial", Font.PLAIN, 14));
        inputField.addActionListener(this);

        // Tombol untuk mengirim pesan
        sendButton = new JButton("Kirim");
        sendButton.setFont(new Font("Arial", Font.BOLD, 14));
        sendButton.addActionListener(this);

        // Panel untuk input dan tombol kirim
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(inputField, BorderLayout.CENTER);
        panel.add(sendButton, BorderLayout.EAST);

        // Menambahkan komponen ke frame
        add(scrollPane, BorderLayout.CENTER);
        add(panel, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String input = inputField.getText();
        if (!input.trim().isEmpty()) {
            chatArea.append("Kamu: " + input + "\n\n");
            chatArea.append("ChatBot: Sedang berpikir...\n\n");
            inputField.setText("");

            // Menggunakan SwingWorker untuk menunda respon ChatBot
            SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
                @Override
                protected Void doInBackground() throws Exception {
                    // Penundaan 2 detik
                    Thread.sleep(2000);
                    return null;
                }

                @Override
                protected void done() {
                    // Menghapus teks "Sedang berpikir..." dan menambahkan respon sebenarnya
                    chatArea.setText(chatArea.getText().replaceFirst("ChatBot: Sedang berpikir...\n\n", ""));
                    String response = getResponse(input);
                    chatArea.append("ChatBot: " + response + "\n\n");
                }
            };
            worker.execute();
        }
    }

    public static String getResponse(String input) {
        switch (input.toLowerCase()) {
            case "halo":
                return "Hai, ada yang bisa aku bantu?";
            case "apa kabar?":
                return "Saya baik, terima kasih!";
            case "siapa namamu, dan siapa yang menciptakanmu?":
                return "Nama saya adalah ChatBot, dan yang menciptakanku adalah Tuan Tommy.";
            case "apa yang bisa kamu lakukan?":
                return "Saya dapat merespons pertanyaan dan perintah dari Anda.";
            case "bye":
                return "Selamat tinggal!";
            case "bagus":
                return "Terima kasih telah memujiku.";
            case "apakah kau bisa menjalankan perintahku?":
                return "Dengan senang hati, saya akan menjalankan permintaan Anda.";
            default:
                return "Maaf, saya tidak mengerti.";
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ChatBot chatBot = new ChatBot();
            chatBot.setVisible(true);
        });
    }
}
