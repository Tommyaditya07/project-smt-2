package base;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class BreakoutGame extends JPanel implements ActionListener, KeyListener {

    private static final int PANEL_WIDTH = 800;
    private static final int PANEL_HEIGHT = 600;
    private static final int BALL_SIZE = 20;
    private static final int PADDLE_WIDTH = 100;
    private static final int PADDLE_HEIGHT = 10;
    private static final int PADDLE_SPEED = 6;
    private static final int TIMER_DELAY = 10;
    private static final int BRICK_WIDTH = 60;
    private static final int BRICK_HEIGHT = 20;
    private static final int BRICK_GAP = 5;

    private static final int BRICKS_PER_ROW = 8;
    private static final int BRICK_ROWS = 4;

    private int ballX = PANEL_WIDTH / 2;
    private int ballY = PANEL_HEIGHT / 2;
    private int ballVelX = 2;
    private int ballVelY = 2;

    private int paddleX = PANEL_WIDTH / 2 - PADDLE_WIDTH / 2;
    private int paddleY = PANEL_HEIGHT - PADDLE_HEIGHT - 30;

    private boolean moveLeft = false;
    private boolean moveRight = false;

    private Timer timer;
    private ArrayList<Rectangle> bricks;

    private int score = 0; // Variable to hold the score
    private JFrame parentFrame; // Reference to the parent frame

    public BreakoutGame(JFrame frame) {
    this.parentFrame = frame; // Initialize the parent frame reference

    setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
    setBackground(Color.BLACK);
    setFocusable(true);
    addKeyListener(this);

    initializeBricks();

    int response = JOptionPane.showConfirmDialog(this, "Apakah Anda ingin memulai game?", "Start Game", JOptionPane.YES_NO_OPTION);
    if (response == JOptionPane.YES_OPTION) {
        timer = new Timer(TIMER_DELAY, this);
        timer.start();
    } else {
        System.exit(0);
    }
}

    private void initializeBricks() {
        bricks = new ArrayList<>();
        int totalBrickWidth = BRICKS_PER_ROW * BRICK_WIDTH + (BRICKS_PER_ROW - 1) * BRICK_GAP;
        int offsetX = (PANEL_WIDTH - totalBrickWidth) / 2;
        for (int row = 0; row < BRICK_ROWS; row++) {
            for (int col = 0; col < BRICKS_PER_ROW; col++) {
                int x = offsetX + col * (BRICK_WIDTH + BRICK_GAP);
                int y = 50 + row * (BRICK_HEIGHT + BRICK_GAP);
                bricks.add(new Rectangle(x, y, BRICK_WIDTH, BRICK_HEIGHT));
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw ball
        g.setColor(Color.RED);
        g.fillOval(ballX, ballY, BALL_SIZE, BALL_SIZE);

        // Draw paddle
        g.setColor(Color.WHITE);
        g.fillRect(paddleX, paddleY, PADDLE_WIDTH, PADDLE_HEIGHT);

        // Draw bricks
        g.setColor(Color.YELLOW);
        for (Rectangle brick : bricks) {
            g.fillRect(brick.x, brick.y, brick.width, brick.height);
        }

        // Draw score
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Score: " + score, 10, 20);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        moveBall();
        movePaddle();
        checkCollision();
        repaint();
    }

    private void moveBall() {
        ballX += ballVelX;
        ballY += ballVelY;

        if (ballX <= 0 || ballX >= PANEL_WIDTH - BALL_SIZE) {
            ballVelX = -ballVelX;
        }

        if (ballY <= 0) {
            ballVelY = -ballVelY;
        }

        if (ballY >= PANEL_HEIGHT - BALL_SIZE) {
            // Ball hit the bottom - game over logic can go here
            timer.stop();
            JOptionPane.showMessageDialog(this, "Game Over\nYour Score: " + score, "Game Over", JOptionPane.YES_NO_OPTION);
            parentFrame.dispose(); // Close the game window
        }
    }

    private void movePaddle() {
        if (moveLeft && paddleX > 0) {
            paddleX -= PADDLE_SPEED;
        }
        if (moveRight && paddleX < PANEL_WIDTH - PADDLE_WIDTH) {
            paddleX += PADDLE_SPEED;
        }
    }

    private void checkCollision() {
        Rectangle ballRect = new Rectangle(ballX, ballY, BALL_SIZE, BALL_SIZE);
        Rectangle paddleRect = new Rectangle(paddleX, paddleY, PADDLE_WIDTH, PADDLE_HEIGHT);

        if (ballRect.intersects(paddleRect)) {
            ballVelY = -ballVelY;
        }

        for (int i = 0; i < bricks.size(); i++) {
            Rectangle brick = bricks.get(i);
            if (ballRect.intersects(brick)) {
                bricks.remove(i);
                ballVelY = -ballVelY;
                score += 10; // Increase score by 10 for each brick hit
                break;
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            moveLeft = true;
        }
        if (key == KeyEvent.VK_RIGHT) {
            moveRight = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            moveLeft = false;
        }
        if (key == KeyEvent.VK_RIGHT) {
            moveRight = false;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Breakout Game");
                BreakoutGame gamePanel = new BreakoutGame(frame);

                frame.add(gamePanel);
                frame.setResizable(false);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
                frame.toFront(); // Bring the game window to the front
                frame.requestFocus(); // Ensure the game window has focus
                gamePanel.requestFocusInWindow(); // Ensure the panel has focus
            }
        });
    }
}
