package base;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;


public class AccountingCalculator extends JFrame implements ActionListener {
    private JTextField display;
    private JPanel panel;
    private double tempFirstNumber = 0;
    private String tempOperation = "";
    private boolean isNewOperation = true;

    public AccountingCalculator() {
        // Frame settings
        setTitle("Accounting Calculator");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Display field
        display = new JTextField();
        display.setFont(new Font("Arial", Font.BOLD, 30));
        display.setHorizontalAlignment(SwingConstants.RIGHT);
        display.setEditable(false);
        display.setBackground(Color.ORANGE);  // Set display background to orange
        display.setForeground(Color.WHITE);  // Set display text color to white
        add(display, BorderLayout.NORTH);

        // Panel for buttons
        panel = new JPanel();
        panel.setLayout(new GridLayout(5, 4, 10, 10));
        panel.setBackground(Color.ORANGE);  // Set panel background to orange

        String[] buttonLabels = {
            "7", "8", "9", "/",
            "4", "5", "6", "x",
            "1", "2", "3", "-",
            "0", ".", "=", "+",
            "C"
        };

        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.setFont(new Font("Arial", Font.BOLD, 20));
            button.setBackground(Color.YELLOW);  // Set button background to yellow
            button.setForeground(Color.BLACK);  // Set button text color to black
            button.addActionListener(this);
            panel.add(button);
        }

        add(panel, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        JButton sourceButton = (JButton) e.getSource();

        // Animate button
        animateButton(sourceButton);

        if (command.charAt(0) >= '0' && command.charAt(0) <= '9' || command.equals(".")) {
            if (isNewOperation) {
                display.setText("");
                isNewOperation = false;
            }
            display.setText(display.getText() + command);
        } else if (command.equals("C")) {
            display.setText("");
            tempFirstNumber = 0;
            tempOperation = "";
            isNewOperation = true;
        } else if (command.equals("=")) {
            calculateResult();
            isNewOperation = true;
        } else {
            if (!isNewOperation) {
                tempFirstNumber = Double.parseDouble(display.getText());
                tempOperation = command;
                isNewOperation = true;
            }
        }
    }

    private void animateButton(JButton button) {
        // Save original color
        Color originalColor = button.getBackground();

        // Set the button to a temporary color
        button.setBackground(Color.LIGHT_GRAY);

        // Use a Timer to reset the color after a short delay
        Timer timer = new Timer(200, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                button.setBackground(originalColor);
            }
        });

        // Ensure the timer only runs once
        timer.setRepeats(false);
        timer.start();
    }

    private void calculateResult() {
        double secondNumber = Double.parseDouble(display.getText());
        double result = 0;

        switch (tempOperation) {
            case "+":
                result = tempFirstNumber + secondNumber;
                break;
            case "-":
                result = tempFirstNumber - secondNumber;
                break;
            case "x":
                result = tempFirstNumber * secondNumber;
                break;
            case "/":
                if (secondNumber != 0) {
                    result = tempFirstNumber / secondNumber;
                } else {
                    JOptionPane.showMessageDialog(this, "Cannot divide by zero", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                break;
            default:
                break;
        }

        display.setText(String.valueOf(result));
        tempFirstNumber = result;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AccountingCalculator calculator = new AccountingCalculator();
            calculator.setVisible(true);
        });
    }
}
