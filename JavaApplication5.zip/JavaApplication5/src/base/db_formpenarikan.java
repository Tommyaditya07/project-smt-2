/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package base;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author USER
 */
public class db_formpenarikan {
    // Informasi koneksi ke database
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/db_tabel";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = ""; // Sesuaikan dengan password MySQL Anda

    public static void simpanPenarikan(String namaBank, String nomorRekening, String jumlahPenarikan) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Langkah 1: Buat koneksi ke database
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);

            // Langkah 2: Buat query untuk menyimpan data penarikan ke dalam tabel order_tabel
            String query = "INSERT INTO order_tabel (bank_name, account_number, amount) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, namaBank);
            preparedStatement.setString(2, nomorRekening);
            preparedStatement.setString(3, jumlahPenarikan);

            // Langkah 3: Eksekusi query untuk menyimpan data
            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Penarikan berhasil disimpan ke database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Langkah 4: Tutup semua objek terkait database
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}