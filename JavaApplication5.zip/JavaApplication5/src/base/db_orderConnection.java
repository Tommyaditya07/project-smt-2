/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package base;
import java.sql.*;
/**
 *
 * @author USER
 */
public class db_orderConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/db_tabel";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static void main(String[] args) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // 1. Buat koneksi ke database
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // 2. Contoh operasi INSERT ke tabel order_tabel
            String sqlInsert = "INSERT INTO order_tabel (nama_barang, deskripsi, jumlah_order, harga, total) VALUES (?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sqlInsert);
            preparedStatement.setString(1, "Barang A");
            preparedStatement.setString(2, "Deskripsi Barang A");
            preparedStatement.setInt(3, 10); // Contoh jumlah order
            preparedStatement.setInt(4, 10000); // Contoh harga satuan
            preparedStatement.setInt(5, 100000); // Contoh total harga
            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Data berhasil ditambahkan ke tabel order_tabel");
            }

            // 3. Contoh operasi SELECT dari tabel order_tabel
            String sqlSelect = "SELECT * FROM order_tabel";
            preparedStatement = connection.prepareStatement(sqlSelect);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String namaBarang = resultSet.getString("nama_barang");
                String deskripsi = resultSet.getString("deskripsi");
                int jumlahOrder = resultSet.getInt("jumlah_order");
                int harga = resultSet.getInt("harga");
                int total = resultSet.getInt("total");
                System.out.println("Nama Barang: " + namaBarang + ", Deskripsi: " + deskripsi + ", Jumlah Order: " + jumlahOrder + ", Harga: " + harga + ", Total: " + total);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 4. Tutup semua sumber daya (resultSet, preparedStatement, connection)
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}