/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package base;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.*;
/**
 *
 * @author USER
 */
public class TrafficGUI extends JFrame {
    
    public TrafficGUI() {
        initComponents();
    }
    
    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Traffic Balok");
        setSize(600, 400);
        setLocationRelativeTo(null); // Posisikan frame di tengah layar
        
        // Panel untuk menampilkan traffic
        JPanel trafficPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawTraffic(g);
            }
            
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(400, 300); // Ukuran panel traffic
            }
        };
        
        getContentPane().add(trafficPanel);
    }
    
    private void drawTraffic(Graphics g) {
        // Menggambar balok traffic dengan warna berbeda
        
        // Balok 1 (merah)
        g.setColor(Color.RED);
        g.fillRect(100, 100, 50, 50); // x, y, lebar, tinggi
        
        // Balok 2 (kuning)
        g.setColor(Color.YELLOW);
        g.fillRect(200, 100, 50, 50); // x, y, lebar, tinggi
        
        // Balok 3 (hijau)
        g.setColor(Color.GREEN);
        g.fillRect(300, 100, 50, 50); // x, y, lebar, tinggi
    }
    
    public static void main(String[] args) {
        // Memulai aplikasi dengan membuat instance dari TrafficGUI
        SwingUtilities.invokeLater(() -> {
            new TrafficGUI().setVisible(true);
        });
    }
}
