/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package base;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
/**
 *
 * @author USER
 */
public class GamePanel extends JPanel {

    private static final int GRID_SIZE = 3;
    private Cell[][] board;
    private boolean playerXTurn;

    public GamePanel() {
        setLayout(new GridLayout(GRID_SIZE, GRID_SIZE));
        board = new Cell[GRID_SIZE][GRID_SIZE];
        playerXTurn = true;

        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                board[row][col] = new Cell();
                add(board[row][col]);
            }
        }

        setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }

    private void checkGameStatus() {
        // Check rows, columns and diagonals
        for (int i = 0; i < GRID_SIZE; i++) {
            if (checkLine(board[i][0], board[i][1], board[i][2]) || 
                checkLine(board[0][i], board[1][i], board[2][i])) {
                return;
            }
        }

        if (checkLine(board[0][0], board[1][1], board[2][2]) || 
            checkLine(board[0][2], board[1][1], board[2][0])) {
            return;
        }

        // Check for a draw
        boolean draw = true;
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                if (board[row][col].isEmpty()) {
                    draw = false;
                    break;
                }
            }
        }

        if (draw) {
            JOptionPane.showMessageDialog(this, "It's a draw!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            resetBoard();
        }
    }

    private boolean checkLine(Cell c1, Cell c2, Cell c3) {
        if (!c1.isEmpty() && c1.getSymbol().equals(c2.getSymbol()) && c2.getSymbol().equals(c3.getSymbol())) {
            JOptionPane.showMessageDialog(this, c1.getSymbol() + " wins!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            resetBoard();
            return true;
        }
        return false;
    }

    private void resetBoard() {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                board[row][col].reset();
            }
        }
        playerXTurn = true;
    }

    private class Cell extends JPanel {
        private String symbol = "";

        public Cell() {
            setBorder(BorderFactory.createLineBorder(Color.BLACK));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    if (symbol.isEmpty()) {
                        symbol = playerXTurn ? "X" : "O";
                        playerXTurn = !playerXTurn;
                        repaint();
                        checkGameStatus();
                    }
                }
            });
        }

        public boolean isEmpty() {
            return symbol.isEmpty();
        }

        public String getSymbol() {
            return symbol;
        }

        public void reset() {
            symbol = "";
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setFont(new Font("Arial", Font.BOLD, 60));
            g.drawString(symbol, getWidth() / 2 - 20, getHeight() / 2 + 20);
        }
    }
}
