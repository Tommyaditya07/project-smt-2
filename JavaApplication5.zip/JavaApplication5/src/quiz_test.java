/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author teknisi
 */
public class quiz_test {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nama, tanggal, kode_barang, nama_barang = "";
        int jum_data, jumlah, harga = 0, total = 0, pembayaran, kembalian;

        System.out.println("------------------------------------------------------------------");
        System.out.println("                      TOKO BETTERSWEET CAKERY                     ");
        System.out.println("------------------------------------------------------------------");
        System.out.println("-                                                                -");
        System.out.println("            DAFTAR MENU TOKO BETTERSWEET CAKERY                   ");
        System.out.println("                                                                  ");
        System.out.println("        Kode Kue    |       Nama Kue       |       Harga Kue      ");
        System.out.println("           A               BLACKFOREST            Rp. 150.000     ");
        System.out.println("           B               OPERA CAKE             Rp. 300.000     ");
        System.out.println("           C               CHEESE CAKE            Rp. 450.000     ");
        System.out.println("------------------------------------------------------------------");

        do {
            System.out.print("Masukkan Nama Pembeli: ");
            nama = scanner.nextLine();

            System.out.print("Masukkan Tanggal Pembelian: ");
            tanggal = scanner.nextLine();

            System.out.print("Masukkan jumlah data yang akan dipesan: ");
            jum_data = scanner.nextInt();
            scanner.nextLine(); // Membersihkan buffer

            String[] kode_barangs = new String[jum_data];
            int[] jumlahs = new int[jum_data];

            for (int i = 0; i < jum_data; i++) {
                System.out.print("Masukkan kode barang ke-" + (i + 1) + " [A/B/C]: ");
                kode_barangs[i] = scanner.nextLine();

                System.out.print("Masukkan Jumlah pembelian: ");
                jumlahs[i] = scanner.nextInt();
                scanner.nextLine(); // Membersihkan buffer
            }

            // Menghitung total harga sebelum pembayaran
            for (int i = 0; i < jum_data; i++) {
                kode_barang = kode_barangs[i];
                jumlah = jumlahs[i];

                switch (kode_barang.toUpperCase()) {
                    case "C":
                        harga = 300000;
                        break;
                    case "B":
                        harga = 150000;
                        break;
                    case "A":
                        harga = 400000;
                        break;
                    default:
                        System.out.println("Kode barang tidak ditemukan!");
                        return;
                }

                total += harga * jumlah;
            }

            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("|                          TOKO BETTER SWEET BEKRY                                       |");
            System.out.println("--------------------------------------------------------------------------------------------------------------------");
            System.out.println("| Nama Petugas : " + nama + "\t\t\t\t\t\t\t\tTanggal : " + tanggal + "|");
            System.out.println("| Data yang dimasukkan: " + jum_data);
            System.out.println("---------------------------------------------------------------------------------------------------------------------");
            System.out.println("|   Data    Kode KUE       Nama Kue       Harga Barang      Jumlah Barang      Total Harga      |");
            System.out.println("|-------------------------------------------------------------------------------------------------------------------|");

            for (int i = 0; i < jum_data; i++) {
                kode_barang = kode_barangs[i];
                jumlah = jumlahs[i];

                switch (kode_barang.toUpperCase()) {
                    case "C":
                        harga = 300000;
                        nama_barang = "BLACKFOREST";
                        break;
                    case "B":
                        harga = 150000;
                        nama_barang = "OPERA CAKE";
                        break;
                    case "A":
                        harga = 400000;
                        nama_barang = "CHEESE CAKE";
                        break;
                    default:
                        System.out.println("Kode barang tidak ditemukan!");
                        return;
                }

                System.out.printf("|%8d%16s%19s%18s%20s%24s|\n", (i + 1), kode_barang, nama_barang, "Rp" + harga, jumlah, "Rp" + (harga * jumlah));
            }
            System.out.println("|-------------------------------------------------------------------------------------------------------------------|");

            System.out.printf("| Total Pembayaran Sebesar Rp %,d |\n", total);

            System.out.print("Masukkan jumlah pembayaran: ");
            pembayaran = scanner.nextInt();

            kembalian = pembayaran - total;

            System.out.printf("| Total Pendapatan pada tanggal %s Sebesar Rp %,56d |\n", tanggal, total);
            System.out.printf("| Kembalian: Rp %,d |\n", kembalian);
            System.out.println("---------------------------------------------------------------------------------------------------------------------");

            scanner.nextLine(); // Membersihkan buffer

            System.out.print("Apakah anda ingin melanjutkan pembelian? [Y/N]: ");
            String lanjut = scanner.nextLine();
            if (!lanjut.equalsIgnoreCase("Y")) {
                break;
            }

            // Reset total untuk pembelian selanjutnya
            total = 0;

        } while (true);

        System.out.println("Terima kasih telah berbelanja di TOKO BETTERSWEET CAKERY!");
    }
}