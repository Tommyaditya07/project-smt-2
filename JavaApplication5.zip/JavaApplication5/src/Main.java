import base.NewJFrame;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Meminta pengguna memasukkan username dan password
        String username = JOptionPane.showInputDialog(null, "Masukkan username:");
        String password = JOptionPane.showInputDialog(null, "Masukkan password:");
        
        // Kondisi untuk memeriksa apakah username dan password sesuai
        if (username.equals("username") && password.equals("password")) {
            // Jika benar, tampilkan pesan "Login Berhasil!" dan buka NewJFrame
            JOptionPane.showMessageDialog(null, "Login Berhasil!");
            NewJFrame menu = new NewJFrame();
            menu.setVisible(true);
            menu.revalidate();
        } else {
            // Jika salah, tampilkan pesan kesalahan
            JOptionPane.showMessageDialog(null, "Username atau password salah!");
        }
    }
}
