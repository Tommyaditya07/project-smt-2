/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author teknisi
 */
public class quiz {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Mendeklarasikan Variabel
        String nama, tanggal, kode_barang, nama_barang = "";
        int jum_data, jumlah, harga = 0, total = 0;

        // User Input
        System.out.print("Masukkan Nama Pembeli: ");
        nama = scanner.nextLine();

        System.out.print("Masukkan Tanggal Pembelian: ");
        tanggal = scanner.nextLine();

        System.out.print("Masukkan jumlah data yang akan pesan: ");
        jum_data = scanner.nextInt();
        scanner.nextLine(); // Membersihkan buffer
        
        // Mendeklarasikan array untuk menyimpan data pembelian
        String[] kode_barangs = new String[jum_data];
        int[] jumlahs = new int[jum_data];

        // Looping   untuk memasukkan data pembelian
        for (int i = 0; i < jum_data; i++) {
            System.out.print("Masukkan kode barang ke-" + (i+1) + " [A/B/C]: ");
            kode_barangs[i] = scanner.nextLine();

            System.out.print("Masukkan Jumlah pembelian: ");
            jumlahs[i] = scanner.nextInt();
            scanner.nextLine(); // Membersihkan buffer
        }

        // Output header
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("|                                     TOKO BETTER SWEET BEKRY                                                      |");
        System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.println("| Nama Petugas : " + nama + "\t\t\t\t\t\t\t\tTanggal : " + tanggal + "|");
        System.out.println("| Data yang dimasukkan: " + jum_data);
        System.out.println("---------------------------------------------------------------------------------------------------------------------");
        System.out.println("|    Data        Kode KUE         Nama Kue         Harga Barang        Jumlah Barang        Total Harga       |");
        System.out.println("|-------------------------------------------------------------------------------------------------------------------|");

        // Loop untuk mencetak output setiap produk
        for (int i = 0; i < jum_data; i++) {
            kode_barang = kode_barangs[i];
            jumlah = jumlahs[i];
            
            // Switch case untuk mendapatkan harga dan nama barang berdasarkan kode barang yang dimasukkan
            switch (kode_barang.toUpperCase()) {
                case "C":
                    harga = 300000;
                    nama_barang = "BLACKFOREST";
                    break;
                case "B":
                    harga = 150000;
                    nama_barang = "OPERA CAKE";
                    break;
                case "A":
                    harga = 400000;
                    nama_barang = "CHEESE CAKE";
                    break;
                default:
                    System.out.println("Kode barang tidak ditemukan!");
                    return;
            }

            // Menghitung total harga untuk setiap produk
            total += harga * jumlah;

            // Output untuk setiap produk
            System.out.printf("|%8d%16s%19s%18s%20s%24s|\n", (i+1), kode_barang, nama_barang, "Rp" + harga, jumlah, "Rp" + (harga * jumlah));
        }
        System.out.println("|-------------------------------------------------------------------------------------------------------------------|");
        System.out.printf("| Total Pendapatan pada tanggal %s Sebesar Rp %,56d |\n", tanggal, total);
        System.out.println("---------------------------------------------------------------------------------------------------------------------");
    }
}

